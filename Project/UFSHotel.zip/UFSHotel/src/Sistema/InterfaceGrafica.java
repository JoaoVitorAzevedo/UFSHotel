/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistema;

/**
 *
 * @author 743554
 */
public class InterfaceGrafica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //cadastro de quartos
        
       
        Controller.cadastrarQuarto(31);
        System.out.println("cadastrado quarto com id 31");
        
        
        

        System.out.println("");
        System.out.println("");

        our_Data date = new our_Data(3,4,1299);
        date.printData();
        System.out.println("oiee");
        System.out.println("");
        
        
        
        // TODO code application logic here
    }
    
}
