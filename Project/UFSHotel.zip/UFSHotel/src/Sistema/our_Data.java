/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistema;

import Framework.Data;

/**
 *
 * @author MartManHunter
 */
public class our_Data extends Data {
    
    public our_Data(int dia, int mes, int ano) {
        super(dia, mes, ano);
        //nossas coisas especificas aqui pra datas
    }
    
   
    
}
