/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistema;
import Framework.TipoEndereco;

/**
 *
 * @author MartManHunter
 */
public class our_Endereco extends TipoEndereco {
    
    public our_Endereco(String cep, String numero, String logradouro, String complemento, String bairro, String cidade, String estado) {
        super(cep, numero, logradouro, complemento, bairro, cidade, estado);
    }

  
    
}
