/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistema;

import Framework.TipoReserva;

/**
 *
 * @author MartManHunter
 */
public class our_Reserva extends TipoReserva {

    public our_Reserva() {
        super(null, null, 0, null, null, null);
    }
    
    

    
    

    
    
    
    
}
